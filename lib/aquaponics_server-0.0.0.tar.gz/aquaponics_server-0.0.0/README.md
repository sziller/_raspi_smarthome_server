# _aquaponics_server
The server / API module for a direct connection to the aquaponic system
