"""
A simple summary of basic Hash function combinations. Use these by comprehensive names!
by Sziller

File checksum for python. Use any file, get its hash.
For single sha256, you can check the results here:
https://emn178.github.io/online-tools/sha256_checksum.html
"""

import hashlib
import json


def single_sha256_byte2byte(preimage: bytes) -> bytes:
    """=== Function name: single_sha256_byte2byte ======================================================================
    Totally simple sha256 hashfunction.
    :param preimage: bytes - data you want to hash
    :return: bytes - the hash
    ============================================================================================== by Sziller ==="""
    return hashlib.sha256(preimage).digest()


def double_sha256_byte2byte(preimage: bytes) -> bytes:
    """=== Function name: single_sha256_byte2byte ======================================================================
    Double sha256 hashfunction. As used in Bitcoin most of the time.
    :param preimage: bytes - data you want to hash
    :return: bytes - the hash
    ============================================================================================== by Sziller ==="""
    return hashlib.sha256(hashlib.sha256(preimage).digest()).digest()


def generate_hashlist(hxstr_list, ):
    byte_list = [bytes.fromhex(_) for _ in hxstr_list]
    return json.dumps([single_sha256_byte2byte(preimage=_).hex() for _ in byte_list])


if __name__ == "__main__":
    # preimage_list = ["01aaf1", "ffaa51", "e3e3e1", "52111e41", "01a2f1", "feea51", "eee4e1", "52b111",
    #                  "01bbf1", "f3a351", "00ef71", "52777741", "7890a1", "12345671", "cccce1"]
    preimage_list = ["01aaf7", "ffaa57", "e3e3e7", "52111e47", "01a2f7", "feea57", "eee4e7", "52b117",
                     "01bbf7", "f3a357", "00ef77", "52777747", "7890a7", "12345677", "cccce7"]
    # preimage_list = ["0eaafe", "f5aa5e", "53e3ee", "82111e4e", "0fa2fe", "f0ea5e", "0ee4ee", "52b10e",
    #                  "01b0fe", "dda35e", "00ed7e", "527e774e", "7440ae", "cc0cee", "deb54e"]
    # preimage_list = ["0eaaff", "f5aa5f", "53e3ef", "82111e4f", "0fa2ff", "f0ea5f", "0ee4ef", "52b10f",
    #                  "01b0ff", "dda35f", "00ed7f", "527e774f", "7440af", "cc0cef", "deb54f"]
    # preimage_list = ["0aaaff", "faaa5f", "5ae3ef", "8a111e4f", "0aa2ff", "faea5f", "0ae4ef", "5ab10f",
    #                  "0ab0ff", "daa35f", "0aed7f", "5a7e774f", "7a40af", "ca0cef", "dab54f"]
    # preimage_list = ["7aaaff", "7aaa5f", "7ae3ef", "7a111e4f", "7aa2ff", "7aea5f", "7ae4ef", "7ab10f",
    #                  "7ab0ff"]
    hash_list = generate_hashlist(hxstr_list=preimage_list)
    print(hash_list)
    
    seed_word = "chainrecorder_mvp"
    seed_word = "MVP of ChainRecorder - Initial recording test. by Sziller"
    seed_word_bytes = bytes(seed_word, "utf-8")
    print(seed_word_bytes)
    
    print(single_sha256_byte2byte(preimage=seed_word_bytes).hex())
    
