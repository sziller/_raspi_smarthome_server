# _raspi_roommanager_server
The server / API module for a direct connection to the roommanager system
